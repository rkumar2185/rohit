package com.cg.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.mvc.model.Book;

@Controller
public class BookController {

	@RequestMapping("/")
	public String showIndex() {
		String view = "index";
		return view;
	}
	
	@RequestMapping(value = "/bookinsert", method = RequestMethod.GET)
	public String showBookRegisterPage(Model model, HttpServletRequest request) {
		
		String view = "bookRegister";

		List<String> list = new ArrayList<>();
		list.add("comedy");
		list.add("action");
		list.add("suspense");
		list.add("horror");
		list.add("fiction");
		
		//model.addAttribute("category",list);

		ServletContext context = request.getServletContext();
		context.setAttribute("categories", list);

		model.addAttribute("book", new Book());

		return view;
	}
	@RequestMapping(value = "/insertBook", method = RequestMethod.POST)
	public String addBook(Model model, @Valid @ModelAttribute("book") Book book, BindingResult result) {

		String view = "";

		if (result.hasErrors()) {
			view = "bookRegister";
		} else {
			
			model.addAttribute("book", book);
			view = "bookSuccess";
		}
		return view;
	}
}
