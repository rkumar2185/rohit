package com.cg.dto;

public class Employee {
	private String name;
	private String  phnNumber;
	
	public Employee(){}
	public Employee(String name, String phnNumber) {
		super();
		this.name = name;
		this.phnNumber = phnNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhnNumber() {
		return phnNumber;
	}
	public void setPhnNumber(String phnNumber) {
		this.phnNumber = phnNumber;
	}
	
	

}
