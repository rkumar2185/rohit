package com.cg.dao;

import java.util.HashSet;

import com.cg.DButil.DButil;
import com.cg.dto.Employee;

public class EmployeedaoImpl implements IEmployeeDao {

	public  HashSet<Employee> fetchAll() {
		System.out.println("step3");
		//it will fetch the details from util class
		return DButil.getAllEmp();
	}

	public void AddEmp(Employee ee) {
		// TODO Auto-generated method stub
		DButil.addEmp(ee);;
	}

}
