package com.cg.dao;

import java.util.HashSet;
import java.util.List;

import com.cg.dto.Employee;

public interface IEmployeeDao {
	public HashSet<Employee> fetchAll();
	public void AddEmp(Employee ee);

}
