package com.cg.service;

import java.util.HashSet;

import com.cg.dao.EmployeedaoImpl;
import com.cg.dao.IEmployeeDao;
import com.cg.dto.Employee;

public class EmployeeServiceImpl implements IEmployeeService {
	IEmployeeDao empdao = new EmployeedaoImpl();

	public HashSet<Employee> fetchAll() {
		System.out.println("step2");
		//it will fetch the details froms dao class
		return empdao.fetchAll();
	}

	public void AddEmp(Employee ee) {
		 empdao.AddEmp(ee);
	}

	

}
