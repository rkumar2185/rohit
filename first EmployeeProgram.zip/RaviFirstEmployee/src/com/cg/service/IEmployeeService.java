package com.cg.service;

import java.util.HashSet;
import java.util.List;

import com.cg.dto.Employee;

public interface IEmployeeService {
	public HashSet<Employee> fetchAll();
	public void  AddEmp(Employee ee);
}
