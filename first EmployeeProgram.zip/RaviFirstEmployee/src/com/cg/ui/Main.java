package com.cg.ui;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.cg.dao.IEmployeeDao;
import com.cg.dto.Employee;
import com.cg.service.EmployeeServiceImpl;
import com.cg.service.IEmployeeService;

public class Main {
	static Scanner sc = null;
	static IEmployeeService service = null;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int choice;
		//while is used to return the first page of ui
while(true){
		System.out
				.println("********Welcome to the Employee World**************");
		System.out.println("1.Fetch All the Details" + "\t2.Exit"
				+ "\t3.Add Employee");
		sc = new Scanner(System.in);
		choice = sc.nextInt();

		switch (choice) {
		case 1:
			fetchAllDetails();
			break;
		case 2:
			Exit();
			break;
		case 3:
			AddEmpl();
			break;

		default:
			Note();
			break;
		}
}

	}

	private static void AddEmpl() {
		
		service = new EmployeeServiceImpl();
		// first we will take the input from the user
		System.out.println("Enter The Employee Name: ");
		String nam = sc.next();
		System.out.println("Enter Phone Number");
		String phnNum = sc.next();

		Employee ee = new Employee(nam, phnNum);
		service.AddEmp(ee);
		System.out.println("Employee added..!");
		return;
		}
		

	

	private static void Note() {
		System.out.println("Please Select Valid option");
	}

	private static void Exit() {
		System.out.println("Thank you visit again");
	}

	private static void fetchAllDetails() {
		System.out.println("step1");
		service = new EmployeeServiceImpl();
		// store all the info in set of var emp and now using iterator will
		// print all the info
		Set<Employee> emp = service.fetchAll();
		Iterator<Employee> iterator = emp.iterator();

		while (iterator.hasNext()) {
			Employee emps = iterator.next();
			System.out.println("Employee Name : " + emps.getName() + "\t"
					+ "Phone Num : " + emps.getPhnNumber());

		}
	}

}
