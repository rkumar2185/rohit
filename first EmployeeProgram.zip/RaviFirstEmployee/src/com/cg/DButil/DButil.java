package com.cg.DButil;

import java.util.HashSet;

import com.cg.dto.Employee;

public class DButil {
	//Actually stored the info of Employee , it will act like database
	 // HashSet is the class whic contains unique object , unorder, unsorted
	static	HashSet<Employee> empset = new HashSet<Employee>();
	static {
        empset.add(new Employee("Munika","9876543212"));
        empset.add(new Employee("Mon","9877543212"));
        empset.add(new Employee("Moa","9870043212"));
        empset.add(new Employee("Moka","9006543212"));
	}
	//created a method where i stored all the details of Employee
	public static HashSet<Employee>  getAllEmp()
	{
		System.out.println("step4");
		return empset;
	}
	public static void addEmp(Employee ee) {
		// TODO Auto-generated method stub
		 empset.add(ee);
	}
	

}
