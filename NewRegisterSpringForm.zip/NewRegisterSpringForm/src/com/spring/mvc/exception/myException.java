package com.spring.mvc.exception;

public class myException extends Exception {

	public myException(String message) {
		super(message);
		
	}

}
