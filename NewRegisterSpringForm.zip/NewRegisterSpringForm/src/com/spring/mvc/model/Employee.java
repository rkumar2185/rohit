package com.spring.mvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
int empId;
	@NotEmpty(message="Name can not be empty")
	@Size(min=3,max=10,message="Name should be in limits")
String name;
	@NotEmpty(message="Designation can not be empty")
String designation;
	@NotEmpty(message="Salary can not be empty")
String salary;
	@NotEmpty(message="Please select the city")
String  city;
	@NotEmpty(message="Please select the gender")
String gender;
	public Employee() {
		super();
	}
	public Employee(int empId, String name, String designation, String salary, String city, String gender) {
		super();
		this.empId = empId;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
		this.city = city;
		this.gender = gender;
	}
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	@Override
	public String toString() {
		return "Employee [name=" + name + ", designation=" + designation + ", salary=" + salary + ", city=" + city
				+ ", gender=" + gender + ", empId=" + empId + "]";
	}	
}